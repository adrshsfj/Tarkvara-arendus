''' Paigalda arvutisse Python ja PyGame
    Tekita uus aken 300*300
    Lisa programmiaknale töönimi ja omanimi, näiteks Lumemees – Karin Eegreid
    Tee valik ning joonista samasugune objekt
    vali värvid nii, et objekt oleks nähtav
    vali suurus nii, et täidaks mõistlikkuse piires akna'''
#inpordib moodulid
import pygame
import sys
#paneb pygame käima
pygame.init()
#loob akna
screen = pygame.display.set_mode([300, 300])
pygame.display.set_caption("Imre Tard - Jaanus Lind")
#ei lase aknal kokku joosta
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill([0, 0, 0])#täidab mustaks
    pygame.draw.circle(screen, [255, 255, 255], [150, 75], 30, 0)#joonistab
    pygame.draw.circle(screen, [255, 255, 255], [150, 140], 40, 0)#joonistab
    pygame.draw.circle(screen, [255, 255, 255], [150, 225], 50, 0)#joonistab
    pygame.draw.circle(screen, [0, 0, 0], [140, 70], 5, 0)#joonistab
    pygame.draw.circle(screen, [0, 0, 0], [160, 70], 5, 0)#joonistab
    pygame.draw.polygon(screen, [255, 0, 0], [[145,80],[150,95],[155,80], [145,80]], 0)#joonistab
    pygame.display.flip()#värskendab ekraani

pygame.quit()#pygame läheb kinni
sys.exit()#programm läheb kinni

