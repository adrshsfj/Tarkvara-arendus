''' Paigalda arvutisse Python ja PyGame
    Tekita uus aken 300*300
    Lisa programmiaknale töönimi ja omanimi, näiteks Lumemees – Karin Eegreid
    Tee valik ning joonista samasugune objekt
    vali värvid nii, et objekt oleks nähtav
    vali suurus nii, et täidaks mõistlikkuse piires akna'''

# Impordi vajalikud moodulid
import pygame
import sys

pygame.init() # Initsialiseeri Pygame
# Loo Pygame'i aken suurusega 300x300 pikslit ja anna sellele pealkiri
screen = pygame.display.set_mode([300, 300])
pygame.display.set_caption("Asd - Jaanus Lind")
# Määra muutuja, mis kontrollib programmi jooksmist, et kokku ei jookseks noh...
running = True
# Põhiline mängutsükkel
while running:
     # Käib läbi kõik Pygame'i sündmused (näiteks kasutaja klõpsud)
    for event in pygame.event.get():
         # x panebb kinni
        if event.type == pygame.QUIT:
            running = False
#täidab tausta
    screen.fill([0, 0, 0])
    #joonistab
    pygame.draw.circle(screen, [255, 0, 0], [150, 65], 40, 0)
    pygame.draw.circle(screen, [255, 255, 0], [150, 150], 40, 0)
    pygame.draw.circle(screen, [0, 255, 0], [150, 235], 40, 0)
    pygame.draw.rect(screen, [128, 128, 128], [100, 15, 100, 270], 2)
    pygame.display.flip() #värskendab akent
#paneb pygame kinni
pygame.quit()
sys.exit()#paneb progre kinni

